/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_calloc.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: imaaitat <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/07 22:36:33 by imaaitat          #+#    #+#             */
/*   Updated: 2022/10/17 21:49:17 by imaaitat         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static void	ft_b_zero(void *s, size_t n)
{
	char	*tmp;
	size_t	i;

	tmp = (char *) s;
	i = 0;
	while (i < n)
		tmp[i++] = '\0';
}

void	*ft_calloc(size_t count, size_t size)
{
	void	*rtn;

	rtn = malloc(size * count);
	if (!rtn)
		return (NULL);
	ft_b_zero(rtn, size * count);
	return (rtn);
}
